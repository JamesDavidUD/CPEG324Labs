To compile:
type "make" and hit enter
All relevant files will be compiled by using GHDL

To test:
The makefile will automatically compile and run the testbench
The testbench will output in text form, and create a waveform (.vcd) file
The output in text will be in integer format, and the waveform has an output in 8 bit signed binary, similar to the LEDs on the FPGA board